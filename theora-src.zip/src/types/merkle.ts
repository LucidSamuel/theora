import type { Spring2D } from '@/lib/animation';

export type TreeMode = 'dense' | 'sparse';

export interface MerkleNode {
  id: string;
  hash: string;
  data?: string;
  left?: MerkleNode;
  right?: MerkleNode;
  depth: number;
  index: number;
  spring: Spring2D;
  highlightIntensity: number;
  isProofPath: boolean;
  isDirty?: boolean;
  isDefault?: boolean;  // true for default/empty nodes in sparse tree
}

export interface MerkleTree {
  root: MerkleNode;
  leaves: MerkleNode[];
  depth: number;
  nodeCount: number;
}

export interface MerkleProof {
  leafIndex: number;
  leafHash: string;
  siblings: { hash: string; position: 'left' | 'right' }[];
  root: string;
}

export interface MultiProof {
  leafIndices: number[];
  leafHashes: string[];
  siblings: { hash: string; depth: number; index: number }[];
  root: string;
  totalSiblings: number;
  individualTotal: number;
  savings: number;
}

export type HashMode = 'sha256' | 'fnv1a';

export interface MerkleState {
  leaves: string[];
  tree: MerkleTree | null;
  hashMode: HashMode;
  selectedLeaf: number | null;
  proof: MerkleProof | null;
  proofStep: number;
  proofValid: boolean | null;
  isBuilding: boolean;
  previousTree: MerkleTree | null;
  dirtyNodes: Set<string>;
}
