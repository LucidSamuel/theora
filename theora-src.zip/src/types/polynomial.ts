export interface EvalPoint {
  x: number;
  y: number;
  label?: string;
}

export interface DegreeBoundResult {
  actualDegree: number;
  claimedDegree: number;
  passes: boolean;
}

export interface KzgStep {
  name: 'commit' | 'challenge' | 'reveal' | 'verify';
  label: string;
  description: string;
}

export interface KzgState {
  commitment: string | null;
  challengeZ: number | null;
  revealedValue: number | null;
  quotientPoly: number[] | null;
  proofHash: string | null;
  verified: boolean | null;
  currentStep: number;
}

export type PolyMode = 'coefficients' | 'lagrange';

export interface FriLayer {
  degree: number;
  coefficients: number[];
  merkleRoot: string;
}

export interface FriState {
  enabled: boolean;
  layers: FriLayer[];
  finalConstant: number;
}

export interface BatchOpenResult {
  points: number[];
  values: number[];
  randomWeights: number[];
  combinedProofHash: string;
}

export interface PolynomialState {
  coefficients: number[];
  compareEnabled?: boolean;
  compareCoefficients?: number[];
  mode: PolyMode;
  lagrangePoints: EvalPoint[];
  evalPoints: EvalPoint[];
  kzg: KzgState;
  viewRange: { xMin: number; xMax: number; yMin: number; yMax: number };
  degreeBound: { enabled: boolean; claimedDegree: number; result: DegreeBoundResult | null } | null;
  batchOpening: { enabled: boolean; points: number[]; result: BatchOpenResult | null } | null;
  friMode: FriState | null;
}
