import { DEMOS, type DemoId } from '@/types';
import { DemoIcon } from '@/components/shared/DemoIcon';

interface SidebarProps {
  activeDemo: DemoId;
  onSwitch: (id: DemoId) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ activeDemo, onSwitch, collapsed, onToggleCollapse }: SidebarProps) {
  return (
    <>
      {/* Desktop sidebar — hidden below md */}
      <aside
        className="hidden md:flex flex-col h-full py-5 px-3 border-r transition-all"
        style={{
          borderColor: 'var(--border)',
          width: collapsed ? 'var(--sidebar-collapsed)' : 'var(--sidebar-width)',
          backgroundColor: 'var(--bg-primary)',
        }}
      >
        <div className="mb-6 px-2 flex items-center justify-between">
          <a href="/" className="no-underline block">
            <span className="text-[13px] font-semibold font-display" style={{ color: 'var(--text-primary)' }}>
              {collapsed ? <span style={{ opacity: 0.4 }}>∴</span> : <><span style={{ opacity: 0.4 }}>∴</span> theora</>}
            </span>
          </a>
          <button
            onClick={onToggleCollapse}
            className="sidebar-icon-btn w-6 h-6 flex items-center justify-center rounded-md text-[10px]"
            style={{ color: 'var(--text-muted)' }}
            aria-label="Collapse sidebar"
          >
            {collapsed ? '\u203A' : '\u2039'}
          </button>
        </div>

        <nav className="flex-1 space-y-1" role="navigation" aria-label="Demo navigation">
          {DEMOS.map((demo) => {
            const isActive = activeDemo === demo.id;
            return (
              <button
                key={demo.id}
                onClick={() => onSwitch(demo.id)}
                className={
                  collapsed
                    ? 'sidebar-nav-item w-full flex items-center justify-center h-10 rounded-lg transition-colors'
                    : 'sidebar-nav-item w-full flex items-start gap-3 px-3 h-10 rounded-lg text-left transition-colors'
                }
                style={{
                  backgroundColor: isActive ? 'var(--button-bg-strong)' : 'transparent',
                  color: isActive ? 'var(--text-primary)' : 'var(--text-muted)',
                  position: 'relative',
                }}
                aria-current={isActive ? 'page' : undefined}
              >
                {isActive && (
                  <span
                    className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-4 rounded-r-full"
                    style={{ backgroundColor: 'var(--text-primary)' }}
                  />
                )}
                <span className="flex items-center h-10 shrink-0">
                  <DemoIcon id={demo.id} size={16} color={isActive ? 'var(--text-primary)' : 'var(--text-muted)'} />
                </span>
                {!collapsed && (
                  <span className="flex items-center h-10 text-xs font-medium min-w-0 truncate">{demo.title}</span>
                )}
              </button>
            );
          })}
        </nav>

        {!collapsed && (
          <div className="mt-auto px-2 pt-4" style={{ borderTop: '1px solid var(--border)' }}>
            <p className="text-[10px]">
              <a
                href="https://x.com/lucidzk"
                target="_blank"
                rel="noopener noreferrer"
                className="no-underline sidebar-footer-link"
                style={{ color: 'var(--text-muted)' }}
              >
                Lucid Samuel
              </a>
            </p>
          </div>
        )}
      </aside>

      {/* Mobile bottom navigation bar — shown only below md */}
      <nav className="mobile-bottom-nav" role="navigation" aria-label="Demo navigation">
        {DEMOS.map((demo) => {
          const isActive = activeDemo === demo.id;
          return (
            <button
              key={demo.id}
              onClick={() => onSwitch(demo.id)}
              className={`mobile-bottom-nav-item${isActive ? ' active' : ''}`}
              aria-current={isActive ? 'page' : undefined}
              style={{
                color: isActive ? 'var(--text-primary)' : 'var(--text-muted)',
                backgroundColor: isActive ? 'var(--button-bg-strong)' : 'transparent',
              }}
            >
              {isActive && (
                <span
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    width: '24px',
                    height: '2px',
                    borderRadius: '0 0 2px 2px',
                    backgroundColor: 'var(--text-primary)',
                  }}
                />
              )}
              <DemoIcon id={demo.id} size={18} color={isActive ? 'var(--text-primary)' : 'var(--text-muted)'} />
              <span className="mobile-bottom-nav-label">{demo.title}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
