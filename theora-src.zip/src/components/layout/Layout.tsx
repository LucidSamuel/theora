import { useState, type ReactNode } from 'react';
import type { DemoId } from '@/types';
import type { Theme } from '@/lib/theme';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { InfoPanel } from './InfoPanel';
import { InfoProvider } from './InfoContext';
import { getSearchParam } from '@/lib/urlState';

interface LayoutProps {
  activeDemo: DemoId;
  onSwitchDemo: (id: DemoId) => void;
  theme: Theme;
  onToggleTheme: () => void;
  children: ReactNode;
}

export interface MobileSheetState {
  infoOpen: boolean;
  setInfoOpen: (open: boolean) => void;
}

export function Layout({ activeDemo, onSwitchDemo, theme, onToggleTheme, children }: LayoutProps) {
  const [infoOpen, setInfoOpen] = useState(true);
  const [navCollapsed, setNavCollapsed] = useState(false);
  // Mobile-specific: info panel shown as a bottom sheet
  const [mobileInfoOpen, setMobileInfoOpen] = useState(false);
  const isEmbed = Boolean(getSearchParam('embed'));

  return (
    <InfoProvider>
      <div className="flex h-full w-full overflow-hidden">
        {!isEmbed && (
          <Sidebar
            activeDemo={activeDemo}
            onSwitch={onSwitchDemo}
            collapsed={navCollapsed}
            onToggleCollapse={() => setNavCollapsed((v) => !v)}
          />
        )}
        <div className="flex-1 flex flex-col min-w-0 h-full">
          {!isEmbed && (
            <Header
              activeDemo={activeDemo}
              theme={theme}
              onToggleTheme={onToggleTheme}
              onToggleInfo={() => setInfoOpen((v) => !v)}
              infoOpen={infoOpen}
              navCollapsed={navCollapsed}
              onToggleNav={() => setNavCollapsed((v) => !v)}
              onSwitchDemo={onSwitchDemo}
            />
          )}
          <main className="flex-1 overflow-hidden app-main-with-mobile-nav">{children}</main>
        </div>
        {!isEmbed && (
          <InfoPanel
            activeDemo={activeDemo}
            isOpen={infoOpen}
            mobileOpen={mobileInfoOpen}
            onMobileClose={() => setMobileInfoOpen(false)}
          />
        )}
        {!isEmbed && (
          <button
            className="mobile-info-toggle"
            onClick={() => setMobileInfoOpen((v) => !v)}
            aria-label="Open info panel"
          >
            &#8505;
          </button>
        )}
      </div>
    </InfoProvider>
  );
}
