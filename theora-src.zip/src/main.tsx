import { StrictMode, lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import './index.css';
import { NotFound } from '@/pages/NotFound';

const Landing = lazy(() => import('./pages/Landing').then(m => ({ default: m.Landing })));
const App = lazy(() => import('./App'));

/** Minimal centered pulse shown while lazy chunks load. */
function PageLoader() {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-primary)',
      }}
    >
      <div className="page-loader-pulse" aria-label="Loading" />
    </div>
  );
}

/** App-shell skeleton shown specifically while the /app route hydrates. */
function AppLoader() {
  return (
    <div
      className="app-skeleton"
      style={{ backgroundColor: 'var(--bg-primary)' }}
      aria-label="Loading application"
    >
      {/* Sidebar placeholder */}
      <div className="app-skeleton__sidebar">
        <div className="app-skeleton__bar app-skeleton__bar--short" />
        <div className="app-skeleton__bar app-skeleton__bar--nav" />
        <div className="app-skeleton__bar app-skeleton__bar--nav" />
        <div className="app-skeleton__bar app-skeleton__bar--nav" />
        <div className="app-skeleton__bar app-skeleton__bar--nav" />
      </div>

      {/* Main content area placeholder */}
      <div className="app-skeleton__main">
        <div className="app-skeleton__header" />
        <div className="app-skeleton__canvas" />
      </div>

      {/* Info panel placeholder */}
      <div className="app-skeleton__info">
        <div className="app-skeleton__bar app-skeleton__bar--short" />
        <div className="app-skeleton__bar" />
        <div className="app-skeleton__bar" />
        <div className="app-skeleton__bar app-skeleton__bar--short" />
      </div>
    </div>
  );
}

/** Wraps each route in a fade-in transition on mount. */
function PageTransition({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  return (
    <div key={location.pathname} className="page-transition-in">
      {children}
    </div>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <PageTransition>
        <Routes>
          <Route
            path="/"
            element={
              <Suspense fallback={<PageLoader />}>
                <Landing />
              </Suspense>
            }
          />
          <Route
            path="/app"
            element={
              <Suspense fallback={<AppLoader />}>
                <App />
              </Suspense>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </PageTransition>
    </BrowserRouter>
  </StrictMode>,
);
