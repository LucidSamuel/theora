import type { ProofNode, VerificationState, IvcChain } from '@/types/recursive';
import type { FrameInfo } from '@/components/shared/AnimatedCanvas';
import { drawGrid, drawLine, drawRoundedRect, hexToRgba, drawArrow, drawGlowCircle } from '@/lib/canvas';
import { getConstantProofSize } from './logic';
import type { FoldingGeometry } from './logic';

const COLORS = {
  dark: {
    background: '#0a0a0a',
    grid: '#1a1a1a',
    text: '#e5e5e5',
    textSecondary: '#a3a3a3',
    pending: '#525252',
    verifying: '#eab308',
    verified: '#22c55e',
    failed: '#ef4444',
    accumulated: '#8b5cf6',
    pallas: '#d4d4d8',
    vesta: '#71717a',
  },
  light: {
    background: '#ffffff',
    grid: '#f5f5f5',
    text: '#171717',
    textSecondary: '#525252',
    pending: '#a3a3a3',
    verifying: '#eab308',
    verified: '#22c55e',
    failed: '#ef4444',
    accumulated: '#7c3aed',
    pallas: '#3f3f46',
    vesta: '#71717a',
  },
};

/**
 * Renders the proof tree in tree mode
 */
export function renderProofTree(
  ctx: CanvasRenderingContext2D,
  frame: FrameInfo,
  root: ProofNode | null,
  positions: Map<string, { x: number; y: number }>,
  verification: VerificationState,
  showPastaCurves: boolean,
  showProofSize: boolean,
  mouseX: number,
  mouseY: number,
  theme: 'dark' | 'light'
): { hovered: { type: 'node'; id: string; label: string; status: string; curve: string } | null } {
  const colors = COLORS[theme];
  const { time, width, height } = frame;

  // Background gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  if (theme === 'dark') {
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#111111');
  } else {
    gradient.addColorStop(0, '#fafafa');
    gradient.addColorStop(1, '#f4f4f5');
  }
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Grid
  drawGrid(ctx, width, height, 40, theme === 'dark' ? 'rgba(240, 231, 222, 0.05)' : 'rgba(63, 63, 70, 0.08)');

  // Vignette
  const vignette = ctx.createRadialGradient(width / 2, height / 2, Math.min(width, height) * 0.2, width / 2, height / 2, Math.max(width, height) * 0.7);
  vignette.addColorStop(0, 'rgba(0,0,0,0)');
  vignette.addColorStop(1, theme === 'dark' ? 'rgba(0,0,0,0.35)' : 'rgba(63,63,70,0.08)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  if (!root) return { hovered: null };

  // Suppress unused lint for verification (used in render logic)
  void verification;

  // Helper to get status color
  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'pending':
        return colors.pending;
      case 'verifying':
        return colors.verifying;
      case 'verified':
        return colors.verified;
      case 'failed':
        return colors.failed;
      case 'accumulated':
        return colors.accumulated;
      default:
        return colors.pending;
    }
  };

  // Draw edges first
  function drawEdges(node: ProofNode): void {
    const pos = positions.get(node.id);
    if (!pos) return;

    for (const child of node.children) {
      const childPos = positions.get(child.id);
      if (!childPos) continue;

      const edgeColor = getStatusColor(child.status);
      ctx.strokeStyle = hexToRgba(edgeColor, 0.4);
      ctx.lineWidth = 2;
      drawLine(ctx, pos.x, pos.y + 20, childPos.x, childPos.y - 20, hexToRgba(edgeColor, 0.4), 2);

      drawEdges(child);
    }
  }

  drawEdges(root);

  let hovered: { type: 'node'; id: string; label: string; status: string; curve: string } | null = null;

  // Draw nodes
  function drawNodes(node: ProofNode): void {
    const pos = positions.get(node.id);
    if (!pos) return;

    const nodeWidth = 80;
    const nodeHeight = 40;
    const x = pos.x - nodeWidth / 2;
    const y = pos.y - nodeHeight / 2;

    // Determine node color
    let nodeColor = colors.verified;
    if (showPastaCurves) {
      nodeColor = node.curve === 'pallas' ? colors.pallas : colors.vesta;
    }

    const statusColor = getStatusColor(node.status);

    // Draw node background
    ctx.fillStyle = hexToRgba(nodeColor, 0.15);
    ctx.strokeStyle = hexToRgba(statusColor, 0.6);
    ctx.lineWidth = 2;
    if (node.status === 'accumulated') {
      ctx.setLineDash([4, 4]);
    }
    drawRoundedRect(ctx, x, y, nodeWidth, nodeHeight, 8);
    ctx.fill();
    ctx.stroke();
    ctx.setLineDash([]);

    // Verification wave effect for verifying nodes
    if (node.status === 'verifying') {
      const pulse = Math.sin(time * 5) * 0.5 + 0.5;
      const ringRadius = 25 + pulse * 10;

      ctx.strokeStyle = hexToRgba(colors.verifying, 0.4 - pulse * 0.3);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, ringRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Second ring
      ctx.strokeStyle = hexToRgba(colors.verifying, 0.2 - pulse * 0.15);
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, ringRadius + 8, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Status icon
    let icon = '⏳';
    if (node.status === 'verifying') {
      icon = '⚡';
    } else if (node.status === 'verified') {
      icon = '✓';
    } else if (node.status === 'failed') {
      icon = '✗';
    } else if (node.status === 'accumulated') {
      icon = '∑';
    }

    ctx.fillStyle = statusColor;
    ctx.font = 'bold 16px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, pos.x, pos.y - 5);

    // Label
    ctx.fillStyle = colors.text;
    ctx.font = '11px monospace';
    ctx.fillText(node.label, pos.x, pos.y + 12);

    // Proof size indicator
    if (showProofSize) {
      getConstantProofSize();
      const barWidth = 40;
      const barHeight = 6;
      const barX = pos.x + nodeWidth / 2 + 8;
      const barY = pos.y - barHeight / 2;

      ctx.fillStyle = hexToRgba(colors.verified, 0.3);
      ctx.fillRect(barX, barY, barWidth, barHeight);

      ctx.fillStyle = colors.textSecondary;
      ctx.font = '9px monospace';
      ctx.textAlign = 'left';
      ctx.fillText('288B', barX + barWidth + 4, pos.y);
    }

    // Recursively draw children
    for (const child of node.children) {
      drawNodes(child);
    }

    // Hover detection
    if (
      mouseX >= x &&
      mouseX <= x + nodeWidth &&
      mouseY >= y &&
      mouseY <= y + nodeHeight
    ) {
      hovered = {
        type: 'node',
        id: node.id,
        label: node.label,
        status: node.status,
        curve: node.curve,
      };
    }
  }

  drawNodes(root);

  return { hovered };
}

/**
 * Renders the IVC chain in IVC mode
 */
export function renderIvcChain(
  ctx: CanvasRenderingContext2D,
  frame: FrameInfo,
  chain: IvcChain | null,
  showPastaCurves: boolean,
  mouseX: number,
  mouseY: number,
  theme: 'dark' | 'light'
): { hovered: { type: 'step'; id: string; label: string; curve: string } | null } {
  const colors = COLORS[theme];
  const { width, height } = frame;

  // Background gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  if (theme === 'dark') {
    gradient.addColorStop(0, '#0a0a0a');
    gradient.addColorStop(1, '#111111');
  } else {
    gradient.addColorStop(0, '#fafafa');
    gradient.addColorStop(1, '#f4f4f5');
  }
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Grid
  drawGrid(ctx, width, height, 40, theme === 'dark' ? 'rgba(240, 231, 222, 0.05)' : 'rgba(63, 63, 70, 0.08)');

  // Vignette
  const vignette = ctx.createRadialGradient(width / 2, height / 2, Math.min(width, height) * 0.2, width / 2, height / 2, Math.max(width, height) * 0.7);
  vignette.addColorStop(0, 'rgba(0,0,0,0)');
  vignette.addColorStop(1, theme === 'dark' ? 'rgba(0,0,0,0.35)' : 'rgba(63,63,70,0.08)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  if (!chain || chain.steps.length === 0) return { hovered: null };

  const stepWidth = 140;
  const stepHeight = 100;
  const spacing = 60;
  const startX = 100;
  const startY = height / 2;

  let accumulatorX = startX - 80;

  // Draw accumulator
  ctx.fillStyle = hexToRgba(colors.verified, 0.2);
  ctx.strokeStyle = hexToRgba(colors.verified, 0.6);
  ctx.lineWidth = 2;
  drawRoundedRect(ctx, accumulatorX - 60, startY - 40, 80, 80, 8);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = colors.text;
  ctx.font = 'bold 12px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('Acc', accumulatorX - 20, startY - 15);

  // Draw current accumulator hash
  const currentStep = chain.steps[chain.currentFoldIndex];
  if (currentStep) {
    ctx.fillStyle = colors.textSecondary;
    ctx.font = '9px monospace';
    const hashDisplay = currentStep.accumulatorHash.slice(0, 8) + '...';
    ctx.fillText(hashDisplay, accumulatorX - 20, startY + 5);
  }

  // Draw each step
  let hovered: { type: 'step'; id: string; label: string; curve: string } | null = null;

  chain.steps.forEach((step, index) => {
    let x = startX + index * (stepWidth + spacing);
    const y = startY - stepHeight / 2;

    // Compress folded steps towards the accumulator
    if (step.folded) {
      x -= (stepWidth + spacing) * 0.7 * (index + 1);
    }

    // Step color
    let stepColor = colors.verified;
    if (showPastaCurves) {
      stepColor = step.curve === 'pallas' ? colors.pallas : colors.vesta;
    }

    // Draw step box
    const alpha = step.folded ? 0.3 : 0.15;
    ctx.fillStyle = hexToRgba(stepColor, alpha);
    ctx.strokeStyle = hexToRgba(step.folded ? colors.verified : stepColor, 0.6);
    ctx.lineWidth = 2;
    drawRoundedRect(ctx, x, y, stepWidth, stepHeight, 8);
    ctx.fill();
    ctx.stroke();

    // Step label
    ctx.fillStyle = colors.text;
    ctx.font = 'bold 13px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(`Step ${index}`, x + stepWidth / 2, y + 10);

    // Curve type
    if (showPastaCurves) {
      ctx.fillStyle = colors.textSecondary;
      ctx.font = '10px monospace';
      ctx.fillText(step.curve, x + stepWidth / 2, y + 28);
    }

    // Input value
    ctx.fillStyle = colors.text;
    ctx.font = '11px monospace';
    ctx.fillText(`Input: ${step.inputValue}`, x + stepWidth / 2, y + 48);

    // Hash
    ctx.fillStyle = colors.textSecondary;
    ctx.font = '9px monospace';
    const hashDisplay = step.accumulatorHash.slice(0, 10) + '...';
    ctx.fillText(hashDisplay, x + stepWidth / 2, y + 68);

    // Folded indicator
    if (step.folded) {
      ctx.fillStyle = colors.verified;
      ctx.font = 'bold 12px monospace';
      ctx.fillText('✓', x + stepWidth - 15, y + 10);
    }

    // Arrow to next step
    if (index < chain.steps.length - 1) {
      const arrowStartX = x + stepWidth + 5;
      const arrowEndX = x + stepWidth + spacing - 5;
      const arrowY = startY;

      drawArrow(ctx, arrowStartX, arrowY, arrowEndX, arrowY, hexToRgba(colors.textSecondary, 0.4), 6);
    }

    if (
      mouseX >= x &&
      mouseX <= x + stepWidth &&
      mouseY >= y &&
      mouseY <= y + stepHeight
    ) {
      hovered = {
        type: 'step',
        id: step.id,
        label: `Step ${index}`,
        curve: step.curve,
      };
    }
  });

  return { hovered };
}

/**
 * Renders a cost metrics overlay in the bottom-right corner of the canvas
 */
export function renderCostOverlay(
  ctx: CanvasRenderingContext2D,
  metrics: { constraintCount: number; proofSizeBytes: number; verifierTimeMs: number },
  width: number,
  height: number,
  theme: 'dark' | 'light'
): void {
  const colors = COLORS[theme];
  const boxW = 180;
  const boxH = 90;
  const boxX = width - boxW - 20;
  const boxY = height - boxH - 20;

  // Background
  ctx.fillStyle = hexToRgba(theme === 'dark' ? '#18181b' : '#f4f4f5', 0.92);
  drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 8);
  ctx.fill();
  ctx.strokeStyle = hexToRgba(colors.textSecondary, 0.3);
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = colors.text;
  ctx.font = 'bold 10px monospace';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText('Cost Metrics', boxX + 10, boxY + 8);

  const barColors = ['#3b82f6', '#22c55e', '#f59e0b'];
  const labels = ['Constraints', 'Proof Size', 'Verifier Time'];
  const values = [
    metrics.constraintCount.toLocaleString(),
    `${metrics.proofSizeBytes}B`,
    `${metrics.verifierTimeMs}ms`,
  ];
  const maxVal = Math.max(metrics.constraintCount, metrics.proofSizeBytes * 100, metrics.verifierTimeMs * 1000);
  const barValues = [metrics.constraintCount, metrics.proofSizeBytes * 100, metrics.verifierTimeMs * 1000];

  for (let i = 0; i < 3; i++) {
    const y = boxY + 26 + i * 20;
    ctx.fillStyle = colors.textSecondary;
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(labels[i]!, boxX + 10, y);

    const barW = 80;
    const barH = 8;
    const barX = boxX + 10;
    const barY = y + 11;

    ctx.fillStyle = hexToRgba(barColors[i]!, 0.2);
    ctx.fillRect(barX, barY, barW, barH);

    const fillW = Math.max(4, (barValues[i]! / maxVal) * barW);
    ctx.fillStyle = hexToRgba(barColors[i]!, 0.7);
    ctx.fillRect(barX, barY, fillW, barH);

    ctx.fillStyle = colors.text;
    ctx.font = '9px monospace';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(values[i]!, boxX + boxW - 10, y + 10);
    ctx.textAlign = 'left';
  }
}

/**
 * Renders the Nova folding visualization panel in the bottom-left of the canvas.
 * Shows P1 and P2 as elliptic curve points animating toward their folded combination F = P1 + r*P2.
 */
export function renderFoldingPanel(
  ctx: CanvasRenderingContext2D,
  frame: FrameInfo,
  foldGeometry: FoldingGeometry | null,
  foldProgress: number,
  theme: 'dark' | 'light'
): void {
  if (!foldGeometry) return;

  // Suppress unused parameter lint (reserved for future external animation control)
  void foldProgress;

  const colors = COLORS[theme];
  const { width, height, time } = frame;

  // Panel dimensions - bottom-left portion of canvas
  const panelH = 160;
  const panelY = height - panelH - 10;
  const panelX = 10;
  const panelW = Math.min(400, width - 20);

  // Panel background
  ctx.fillStyle = hexToRgba(theme === 'dark' ? '#18181b' : '#f4f4f5', 0.92);
  drawRoundedRect(ctx, panelX, panelY, panelW, panelH, 10);
  ctx.fill();
  ctx.strokeStyle = hexToRgba(colors.textSecondary, 0.3);
  ctx.lineWidth = 1;
  ctx.stroke();

  // Title
  ctx.fillStyle = colors.text;
  ctx.font = 'bold 11px monospace';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText('Nova Folding', panelX + 12, panelY + 10);

  // Coordinate system center
  const cx = panelX + panelW / 2;
  const cy = panelY + panelH / 2 + 10;
  const scale = 0.6;

  const { point1, point2, foldedPoint, randomChallenge } = foldGeometry;

  // Screen-space positions for P1, P2, and folded point
  const p1x = cx + point1.x * scale;
  const p1y = cy + point1.y * scale;
  const p2x = cx + point2.x * scale;
  const p2y = cy + point2.y * scale;
  const fpx = cx + foldedPoint.x * scale;
  const fpy = cy + foldedPoint.y * scale;

  // Draw dashed connection lines from P1 and P2 toward folded point
  ctx.setLineDash([3, 3]);
  drawLine(ctx, p1x, p1y, fpx, fpy, hexToRgba('#3b82f6', 0.3), 1);
  drawLine(ctx, p2x, p2y, fpx, fpy, hexToRgba('#f59e0b', 0.3), 1);
  ctx.setLineDash([]);

  // Animate: dots travel from P1/P2 toward folded point using a sin-based oscillation
  const animProgress = Math.min(1, (Math.sin(time * 1.5) + 1) / 2);
  const anim1x = p1x + (fpx - p1x) * animProgress;
  const anim1y = p1y + (fpy - p1y) * animProgress;
  const anim2x = p2x + (fpx - p2x) * animProgress;
  const anim2y = p2y + (fpy - p2y) * animProgress;

  // Draw P1
  drawGlowCircle(ctx, p1x, p1y, 6, '#3b82f6', 0.5);
  ctx.fillStyle = '#3b82f6';
  ctx.font = '10px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillText('P1', p1x, p1y - 10);

  // Draw P2
  drawGlowCircle(ctx, p2x, p2y, 6, '#f59e0b', 0.5);
  ctx.fillStyle = '#f59e0b';
  ctx.fillText('P2', p2x, p2y - 10);

  // Draw animated traveling dots
  drawGlowCircle(ctx, anim1x, anim1y, 3, '#3b82f6', 0.7);
  drawGlowCircle(ctx, anim2x, anim2y, 3, '#f59e0b', 0.7);

  // Draw folded point F
  drawGlowCircle(ctx, fpx, fpy, 8, '#22c55e', 0.6);
  ctx.fillStyle = '#22c55e';
  ctx.font = 'bold 10px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillText('F', fpx, fpy - 12);

  // Equation label at bottom of panel
  ctx.fillStyle = colors.text;
  ctx.font = '10px monospace';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'bottom';
  ctx.fillText(
    `F = P1 + r\u00B7P2,  r = ${randomChallenge.toFixed(1)}`,
    panelX + 12,
    panelY + panelH - 8
  );
}
