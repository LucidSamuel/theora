import { hashLeaf, hashInternal, poseidonHash, mimcHash, type HashFunction } from '@/lib/hash';
import { createSpring2D } from '@/lib/animation';
import type { MerkleNode, MerkleTree, MerkleProof, MultiProof } from '@/types/merkle';

// Build tree bottom-up. If odd leaf count, duplicate last leaf.
export async function buildMerkleTree(leaves: string[], mode: HashFunction): Promise<MerkleTree | null> {
  if (leaves.length === 0) return null;

  // Hash all leaves
  let nodes: MerkleNode[] = [];
  for (let i = 0; i < leaves.length; i++) {
    const leafData = leaves[i];
    if (!leafData) continue;
    const hash = await hashLeaf(leafData, mode);
    nodes.push({
      id: `leaf-${i}`,
      hash,
      data: leafData,
      depth: 0, // will be recalculated
      index: i,
      spring: createSpring2D(0, 0),
      highlightIntensity: 0,
      isProofPath: false,
    });
  }

  // Duplicate last if odd
  if (nodes.length > 1 && nodes.length % 2 !== 0) {
    const last = nodes[nodes.length - 1];
    if (last) {
      nodes.push({ ...last, id: `leaf-${nodes.length}-dup`, index: nodes.length });
    }
  }

  let depth = 0;
  let currentLevel = nodes;
  const allLeaves = [...nodes];

  while (currentLevel.length > 1) {
    const nextLevel: MerkleNode[] = [];
    for (let i = 0; i < currentLevel.length; i += 2) {
      const left = currentLevel[i];
      const right = currentLevel[i + 1];
      if (!left) continue;
      const rightNode = right ?? left;
      const hash = await hashInternal(left.hash, rightNode.hash, mode);
      nextLevel.push({
        id: `node-${depth + 1}-${i / 2}`,
        hash,
        left,
        right: rightNode,
        depth: depth + 1,
        index: Math.floor(i / 2),
        spring: createSpring2D(0, 0),
        highlightIntensity: 0,
        isProofPath: false,
      });
    }
    depth++;
    currentLevel = nextLevel;
  }

  const root = currentLevel[0];
  if (!root) return null;

  // Fix depths (root should be 0, leaves at max)
  const treeDepth = depth;
  function fixDepth(node: MerkleNode, d: number) {
    node.depth = d;
    if (node.left) fixDepth(node.left, d + 1);
    if (node.right) fixDepth(node.right, d + 1);
  }
  fixDepth(root, 0);

  return { root, leaves: allLeaves, depth: treeDepth, nodeCount: allLeaves.length * 2 - 1 };
}

export function generateProof(tree: MerkleTree, leafIndex: number, _mode: HashFunction): MerkleProof | null {
  if (leafIndex < 0 || leafIndex >= tree.leaves.length) return null;
  const leaf = tree.leaves[leafIndex];
  if (!leaf) return null;

  // Walk from leaf to root, collecting siblings
  const siblings: { hash: string; position: 'left' | 'right' }[] = [];

  function findPath(node: MerkleNode, targetId: string): MerkleNode[] | null {
    if (node.id === targetId) return [node];
    if (node.left) {
      const path = findPath(node.left, targetId);
      if (path) return [node, ...path];
    }
    if (node.right) {
      const path = findPath(node.right, targetId);
      if (path) return [node, ...path];
    }
    return null;
  }

  const path = findPath(tree.root, leaf.id);
  if (!path) return null;

  // For each node on path (except leaf), find the sibling
  for (let i = 1; i < path.length; i++) {
    const parent = path[i - 1];
    const current = path[i];
    if (!parent || !current) continue;
    if (parent.left && parent.right) {
      if (parent.left.id === current.id) {
        siblings.push({ hash: parent.right.hash, position: 'right' });
      } else {
        siblings.push({ hash: parent.left.hash, position: 'left' });
      }
    }
  }

  // Reverse: collected top-to-bottom, but verification walks bottom-to-top
  return {
    leafIndex,
    leafHash: leaf.hash,
    siblings: siblings.reverse(),
    root: tree.root.hash,
  };
}

export async function verifyProof(proof: MerkleProof, mode: HashFunction): Promise<boolean> {
  let currentHash = proof.leafHash;
  for (const sibling of proof.siblings) {
    if (sibling.position === 'right') {
      currentHash = await hashInternal(currentHash, sibling.hash, mode);
    } else {
      currentHash = await hashInternal(sibling.hash, currentHash, mode);
    }
  }
  return currentHash === proof.root;
}

// Layout: root at top, leaves at bottom
export function computeTreeLayout(tree: MerkleTree, w: number, h: number): Map<string, { x: number; y: number }> {
  const positions = new Map<string, { x: number; y: number }>();
  const padding = 60;
  const usableW = w - padding * 2;
  const usableH = h - padding * 2;

  function layout(node: MerkleNode, left: number, right: number) {
    const x = padding + (left + right) / 2 * usableW;
    const y = padding + (node.depth / Math.max(tree.depth, 1)) * usableH;
    positions.set(node.id, { x, y });
    if (node.left && node.right) {
      const mid = (left + right) / 2;
      layout(node.left, left, mid);
      layout(node.right, mid, right);
    }
  }

  layout(tree.root, 0, 1);
  return positions;
}

export function getProofSteps(proof: MerkleProof): { description: string; hash: string; siblingHash: string; position: string }[] {
  return proof.siblings.map((s, i) => ({
    description: `Step ${i + 1}: Hash with ${s.position} sibling`,
    hash: i === 0 ? proof.leafHash : `(result of step ${i})`,
    siblingHash: s.hash,
    position: s.position,
  }));
}

/**
 * Build a sparse Merkle tree with fixed depth.
 * Only specified key-value pairs are non-default.
 * Default leaves hash to a known constant.
 */
export async function buildSparseMerkleTree(
  keyValues: Map<number, string>,
  depth: number,
  mode: HashFunction
): Promise<MerkleTree | null> {
  if (depth < 1 || depth > 8) return null;

  // Compute default hashes bottom-up
  const defaultHashes: string[] = new Array(depth + 1);
  defaultHashes[depth] = await hashLeaf('', mode); // empty leaf default
  for (let d = depth - 1; d >= 0; d--) {
    defaultHashes[d] = await hashInternal(defaultHashes[d + 1]!, defaultHashes[d + 1]!, mode);
  }

  // Build tree recursively, pruning default subtrees
  async function buildNode(d: number, idx: number): Promise<MerkleNode> {
    if (d === depth) {
      // Leaf level
      const data = keyValues.get(idx);
      if (data !== undefined) {
        const hash = await hashLeaf(data, mode);
        return {
          id: `sparse-leaf-${idx}`,
          hash,
          data,
          depth: d,
          index: idx,
          spring: createSpring2D(0, 0),
          highlightIntensity: 0,
          isProofPath: false,
          isDirty: false,
          isDefault: false,
        };
      }
      return {
        id: `sparse-leaf-${idx}`,
        hash: defaultHashes[depth]!,
        depth: d,
        index: idx,
        spring: createSpring2D(0, 0),
        highlightIntensity: 0,
        isProofPath: false,
        isDirty: false,
        isDefault: true,
      };
    }

    // Check if entire subtree is default
    const subtreeSize = Math.pow(2, depth - d);
    const startLeaf = idx * subtreeSize;
    let hasNonDefault = false;
    for (let i = startLeaf; i < startLeaf + subtreeSize; i++) {
      if (keyValues.has(i)) {
        hasNonDefault = true;
        break;
      }
    }

    if (!hasNonDefault) {
      return {
        id: `sparse-node-${d}-${idx}`,
        hash: defaultHashes[d]!,
        depth: d,
        index: idx,
        spring: createSpring2D(0, 0),
        highlightIntensity: 0,
        isProofPath: false,
        isDirty: false,
        isDefault: true,
      };
    }

    const left = await buildNode(d + 1, idx * 2);
    const right = await buildNode(d + 1, idx * 2 + 1);
    const hash = await hashInternal(left.hash, right.hash, mode);

    return {
      id: `sparse-node-${d}-${idx}`,
      hash,
      left,
      right,
      depth: d,
      index: idx,
      spring: createSpring2D(0, 0),
      highlightIntensity: 0,
      isProofPath: false,
      isDirty: false,
      isDefault: false,
    };
  }

  const root = await buildNode(0, 0);

  // Collect non-default leaves
  const leaves: MerkleNode[] = [];
  function collectLeaves(node: MerkleNode) {
    if (!node.left && !node.right) {
      if (!node.isDefault) leaves.push(node);
      return;
    }
    if (node.left) collectLeaves(node.left);
    if (node.right) collectLeaves(node.right);
  }
  collectLeaves(root);

  return {
    root,
    leaves,
    depth,
    nodeCount: countSparseNodes(root),
  };
}

function countSparseNodes(node: MerkleNode): number {
  if (node.isDefault && !node.left && !node.right) return 1;
  let count = 1;
  if (node.left) count += countSparseNodes(node.left);
  if (node.right) count += countSparseNodes(node.right);
  return count;
}

/**
 * Compute hash comparison: same tree data with different hash functions
 */
export async function computeHashComparison(
  leaves: string[]
): Promise<{ name: string; root: string; outputLength: number; style: string; zkFriendly: boolean }[]> {
  if (leaves.length === 0) return [];

  // SHA-256
  const sha256Tree = await buildMerkleTree(leaves, 'sha256');
  // FNV-1a
  const fnv1aTree = await buildMerkleTree(leaves, 'fnv1a');

  // Poseidon (simulated) - compute root by hashing leaves
  let poseidonLeaves = leaves.map(l => poseidonHash('\x00' + l));
  while (poseidonLeaves.length > 1) {
    if (poseidonLeaves.length % 2 !== 0) poseidonLeaves.push(poseidonLeaves[poseidonLeaves.length - 1]!);
    const next: string[] = [];
    for (let i = 0; i < poseidonLeaves.length; i += 2) {
      next.push(poseidonHash('\x01' + poseidonLeaves[i]! + poseidonLeaves[i + 1]!));
    }
    poseidonLeaves = next;
  }

  // MiMC (simulated)
  let mimcLeaves = leaves.map(l => mimcHash('\x00' + l));
  while (mimcLeaves.length > 1) {
    if (mimcLeaves.length % 2 !== 0) mimcLeaves.push(mimcLeaves[mimcLeaves.length - 1]!);
    const next: string[] = [];
    for (let i = 0; i < mimcLeaves.length; i += 2) {
      next.push(mimcHash('\x01' + mimcLeaves[i]! + mimcLeaves[i + 1]!));
    }
    mimcLeaves = next;
  }

  return [
    {
      name: 'SHA-256',
      root: sha256Tree?.root.hash ?? '',
      outputLength: 64,
      style: 'Bitwise',
      zkFriendly: false,
    },
    {
      name: 'FNV-1a',
      root: fnv1aTree?.root.hash ?? '',
      outputLength: 8,
      style: 'Bitwise (fast)',
      zkFriendly: false,
    },
    {
      name: 'Poseidon',
      root: poseidonLeaves[0] ?? '',
      outputLength: 32,
      style: 'Algebraic (x³)',
      zkFriendly: true,
    },
    {
      name: 'MiMC',
      root: mimcLeaves[0] ?? '',
      outputLength: 32,
      style: 'Algebraic (x³)',
      zkFriendly: true,
    },
  ];
}

export function computeTreeDiff(oldTree: MerkleTree | null, newTree: MerkleTree | null): Set<string> {
  const dirtyNodes = new Set<string>();
  if (!oldTree || !newTree) return dirtyNodes;

  function compare(oldNode: MerkleNode | undefined, newNode: MerkleNode | undefined): void {
    if (!oldNode || !newNode) return;
    if (oldNode.hash !== newNode.hash) {
      dirtyNodes.add(newNode.id);
    }
    compare(oldNode.left, newNode.left);
    compare(oldNode.right, newNode.right);
  }

  compare(oldTree.root, newTree.root);
  return dirtyNodes;
}

export function getProofPathNodes(tree: MerkleTree, leafIndex: number): MerkleNode[] | null {
  const leaf = tree.leaves[leafIndex];
  if (!leaf) return null;

  function findPath(node: MerkleNode, targetId: string): MerkleNode[] | null {
    if (node.id === targetId) return [node];
    if (node.left) {
      const path = findPath(node.left, targetId);
      if (path) return [node, ...path];
    }
    if (node.right) {
      const path = findPath(node.right, targetId);
      if (path) return [node, ...path];
    }
    return null;
  }

  return findPath(tree.root, leaf.id);
}

/**
 * Generate a multi-proof for multiple leaves.
 * Deduplicates shared sibling nodes across proof paths.
 */
export function generateMultiProof(tree: MerkleTree, leafIndices: number[]): MultiProof | null {
  if (leafIndices.length === 0 || !tree) return null;

  // For each leaf, get the proof path nodes
  const pathSets: Set<string>[] = [];
  for (const idx of leafIndices) {
    const pathNodes = getProofPathNodes(tree, idx);
    if (!pathNodes) return null;
    pathSets.push(new Set(pathNodes.map(n => n.id)));
  }

  // Union of all proof path node IDs
  const proofPathUnion = new Set<string>();
  for (const ps of pathSets) {
    for (const id of ps) proofPathUnion.add(id);
  }

  // Walk the tree collecting sibling hashes needed (nodes adjacent to a path node but not on any path)
  const siblings: { hash: string; depth: number; index: number }[] = [];
  const siblingIdSet = new Set<string>();

  function collectSiblings(node: MerkleNode): void {
    if (!node.left || !node.right) return;

    const leftOnPath = proofPathUnion.has(node.left.id);
    const rightOnPath = proofPathUnion.has(node.right.id);

    if (leftOnPath && !rightOnPath && !siblingIdSet.has(node.right.id)) {
      siblingIdSet.add(node.right.id);
      siblings.push({ hash: node.right.hash, depth: node.right.depth, index: node.right.index });
    }
    if (rightOnPath && !leftOnPath && !siblingIdSet.has(node.left.id)) {
      siblingIdSet.add(node.left.id);
      siblings.push({ hash: node.left.hash, depth: node.left.depth, index: node.left.index });
    }

    collectSiblings(node.left);
    collectSiblings(node.right);
  }

  collectSiblings(tree.root);

  // Calculate individual proof sizes for comparison
  let individualTotal = 0;
  for (const idx of leafIndices) {
    const proof = generateProof(tree, idx, 'fnv1a');
    if (proof) individualTotal += proof.siblings.length;
  }

  const leafHashes = leafIndices.map(idx => {
    const leaf = tree.leaves[idx];
    return leaf ? leaf.hash : '';
  });

  return {
    leafIndices,
    leafHashes,
    siblings,
    root: tree.root.hash,
    totalSiblings: siblings.length,
    individualTotal,
    savings: individualTotal - siblings.length,
  };
}
