export async function sha256(data: string): Promise<string> {
  const encoded = new TextEncoder().encode(data);
  const buffer = await crypto.subtle.digest('SHA-256', encoded);
  return Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function fnv1a(data: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < data.length; i++) {
    hash ^= data.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * Simulated Poseidon hash (algebraic hash, ZK-friendly)
 * Not cryptographically real — demonstrates different hash characteristics
 */
export function poseidonHash(data: string): string {
  // Simulate algebraic hash with field arithmetic characteristics
  let state = 0x736f6e65; // "sone"
  for (let i = 0; i < data.length; i++) {
    state = state ^ data.charCodeAt(i);
    // Simulate cube operation (x^3) in field arithmetic
    state = Math.imul(state, state) ^ Math.imul(state, 0x9e3779b9);
    state = state >>> 0;
  }
  // Produce a 32-char hex output to match typical field element
  let hash = '';
  let s = state;
  for (let round = 0; round < 4; round++) {
    s = Math.imul(s ^ (s >>> 16), 0x45d9f3b) >>> 0;
    hash += s.toString(16).padStart(8, '0');
  }
  return hash;
}

/**
 * Simulated MiMC hash (minimal multiplicative complexity)
 * Not cryptographically real — demonstrates different hash characteristics
 */
export function mimcHash(data: string): string {
  // Simulate MiMC's cube-based round function
  let state = 0x6d696d63; // "mimc"
  const roundConstants = [0x243f6a88, 0x85a308d3, 0x13198a2e, 0x03707344];

  for (let i = 0; i < data.length; i++) {
    state = state ^ data.charCodeAt(i);
    for (let r = 0; r < roundConstants.length; r++) {
      state = (state + roundConstants[r]!) >>> 0;
      // x^3 round function
      state = Math.imul(Math.imul(state, state) >>> 0, state) >>> 0;
    }
  }

  let hash = '';
  let s = state;
  for (let round = 0; round < 4; round++) {
    s = Math.imul(s ^ (s >>> 13), 0x7feb352d) >>> 0;
    hash += s.toString(16).padStart(8, '0');
  }
  return hash;
}

export interface HashComparisonEntry {
  name: string;
  root: string;
  outputLength: number;
  style: string;
  zkFriendly: boolean;
}

export type HashFunction = 'sha256' | 'fnv1a';

export async function hashLeaf(data: string, mode: HashFunction): Promise<string> {
  const prefixed = '\x00' + data;
  return mode === 'sha256' ? sha256(prefixed) : fnv1a(prefixed);
}

export async function hashInternal(left: string, right: string, mode: HashFunction): Promise<string> {
  const prefixed = '\x01' + left + right;
  return mode === 'sha256' ? sha256(prefixed) : fnv1a(prefixed);
}
